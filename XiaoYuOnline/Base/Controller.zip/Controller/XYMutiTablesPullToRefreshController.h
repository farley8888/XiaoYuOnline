//
//  XYMutiTablesPullToRefreshController.h
//  XiaoYuOnline
//
//  Created by wei.chen on 2018/4/27.
//  Copyright © 2018年 XiaoYuOnline. All rights reserved.
//

#import "XYBaseViewController.h"

@interface XYMutiTablesPullToRefreshController : XYBaseViewController

@end
