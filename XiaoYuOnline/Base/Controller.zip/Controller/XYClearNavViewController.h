//
//  XYClearNavViewController.h
//  XiaoYuOnline
//
//  Created by wei.chen on 2018/4/5.
//  Copyright © 2018年 XiaoYuOnline. All rights reserved.
//

#import "XYBaseViewController.h"

/**
 导航条颜色透明
 */
@interface XYClearNavViewController : XYBaseViewController

@end
